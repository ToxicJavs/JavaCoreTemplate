package changemyname;

import static sbcc.Core.*;
import static java.lang.System.*;
import static org.apache.commons.lang3.StringUtils.*;
import static java.util.Arrays.*;
import static java.lang.Math.*;

/**
 * 
 * @author your_name_here
 *
 */
public class Main {

	public static void main(String[] args) {

	}

}
